// Project Identifier: AD48FB4835AF347EB0CA8009E24C3B13F8519882
#include "p2a-heap.h"
#include "planet.h"

int main(int argc, char *argv[]) {
    std::ios::sync_with_stdio(false);
    Galaxy g(argc, argv);
    g.runSim();
}